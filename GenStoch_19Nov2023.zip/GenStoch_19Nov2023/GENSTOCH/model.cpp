// Copyright (c) 2023 Eric Larsen
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the “Software”), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
// ****************************************************************************
// ****************************************************************************
//
//
#include "model.h"

// Constructor
Model::Model(const Instance *_inst) :
		inst(_inst)
{
	iloModel = IloModel(iloEnv);
	cplex = IloCplex(iloModel);
	// set up 2-dimensional array of flow variables
	createXVariables();
	// set up constraints restricting net flow on each node for each commodity
	createConstraints2();
	// set up constraints restricting total flow on each arc
	createConstraints3();
	// silence CPLEX
	cplex.setOut(iloEnv.getNullStream());
	cplex.setWarning(iloEnv.getNullStream());
	cplex.setError(iloEnv.getNullStream());
	cplex.setParam(IloCplex::Param::RootAlgorithm, IloCplex::Network);
}

// Verifies if scenario is feasible.
bool Model::testScenario()
{
	modify();
	return cplex.solve();
}

// Modifies model to reflect scenario currently under test.
void Model::modify()
{
	int countComm = 0;

	// update source and sink volumes of each commodity
	for (int n = 0; n < inst->numbNodes; n++)
		for (int k = 0; k < inst->numbCommods; k++)
		{
			int bound = (int) inst->stochElems[DEMAND][k];

			if (inst->commods[k].dest == n)
				bound = -bound;
			else if (inst->commods[k].orig != n)
				bound = 0;

			ctr2[n][k].setBounds(bound, bound);
		}

	// update upper bounds on total flow on each arc
	for (int a = 0; a < inst->numbArcs; a++)
		ctr3[a].setUB(inst->stochElems[CAP_ARC][a]);

	// update upper bounds on flow of each commodity on each arc
	for (int a = 0; a < inst->numbArcs; a++)
		for (int k = 0; k < inst->numbCommods; k++)
			X_ak[a][k].setUB(inst->stochElems[CAP_COMMOD][countComm++]);
}

// Sets up 2-dimensional array of flow variables (first dim is arcs,
// second dim is commodities).
void Model::createXVariables()
{
	X_ak = IloNumVarArray2(iloEnv, inst->numbArcs);

	for (int a = 0; a < inst->numbArcs; a++)
	{
		X_ak[a] = IloNumVarArray(iloEnv, inst->numbCommods, 0, IloInfinity);
	}
}

// Sets up constraints restricting net flow on each node for each
// commodity.
void Model::createConstraints2()
{
	ctr2 = IloRangeArray2(iloEnv, inst->numbNodes);

	for (int n = 0; n < inst->numbNodes; n++)
	{
		ctr2[n] = IloRangeArray(iloEnv);

		for (int k = 0; k < inst->numbCommods; k++)
		{
			IloExpr exp(iloEnv);

			for (uint a = 0; a < inst->nodes[n].arcOut.size(); a++)
				exp += X_ak[inst->nodes[n].arcOut[a]][k];

			for (uint a = 0; a < inst->nodes[n].arcIn.size(); a++)
				exp -= X_ak[inst->nodes[n].arcIn[a]][k];

			ctr2[n].add(exp == 0.0);
			exp.end();
		}

		iloModel.add(ctr2[n]);
	}
}

// Sets up constraints restricting total flow on each arc.
void Model::createConstraints3()
{
	ctr3 = IloRangeArray(iloEnv);

	for (int a = 0; a < inst->numbArcs; a++)
		ctr3.add(IloSum(X_ak[a]) <= 0.0);

	iloModel.add(ctr3);
}
