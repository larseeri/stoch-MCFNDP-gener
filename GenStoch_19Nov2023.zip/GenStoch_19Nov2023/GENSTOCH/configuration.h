// Copyright (c) 2023 Eric Larsen
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the “Software”), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
// ****************************************************************************
// ****************************************************************************
//
//
#ifndef __PARAMETER_H__
#define __PARAMETER_H__

#include <iostream>
#include <cstring>
#include <vector>

#include "../HOYLAND_KAUT_WALLACE/matrix.h"

using namespace std;

// input and output formats available
enum IO_FORMAT
{
	DOW = 0, STD
};

// distributional characteristics of moments available
enum MOMENTS_DIST_CHARACT
{
	UNIFORM = 0, TRIANGULAR, UNKNOWN
};

// Types of stochastic elements (i.e. commodity demands, total arc
// capacities, capacities per arc and commodity, fixed costs per arc,
// variable costs per arc and commodity) that can be randomized.
// MAX_TYPE will be used as an index upper bound when looping over
// STOCH_ELEMS_TYPE.
enum STOCH_ELEMS_TYPE
{
	DEMAND = 0,
	CAP_ARC,
	CAP_COMMOD,
	FIXED_COST,
	VAR_COST,
	MAX_TYPE,
	ALL_TYPES = MAX_TYPE
};

const string formats[] =
{ "dow", "std" };

const string elements[] =
{ "demand", "capacity of arc", "capacity of commodarc", "fixed cost of arc",
		"variable cost of commodarc" };

// Signaling which elements are to be stochastic (i.e. are to vary across
// generated scenarios) is done with the following binary flags. Their sum
// is assigned to configuration parameter X.
const int flagStochDemand = 1;
const int flagStochArcCapac = 2;
const int flagStochCommodArcCapac = 4;
const int flagStochFixedCost = 8;
const int flagStochVarCost = 16;

// Holding the elements belonging to a particular type in STOCH_ELEMS_TYPE
struct StochElem
{
	// pointer of array containing the elements
	double *ptr;

	// type of the stochastic element
	STOCH_ELEMS_TYPE type;

	// size of array
	uint size;

	// operators retrieving individual elements stored in the array
	double& operator[](int index)
	{
		return ptr[index];
	}
	const double& operator[](int index) const
	{
		return ptr[index];
	}
};

typedef vector<StochElem> VectElem;
typedef vector<STOCH_ELEMS_TYPE> VectStoch;
typedef vector<double> VectDbl;
typedef vector<VectDbl> MatDbl;

// Processing the program input parameters
// (See main.cpp for details on construction of command line.)
struct Configuration
{
	// format of instance
	IO_FORMAT instanceFormat;

	// distributional characteristics of moments
	MOMENTS_DIST_CHARACT momentsCharacts;

	// generate or read moments
	bool generMoments;

	// alpha parameter used in generating moments
	double alpha;

	// beta parameter used in generating moments
	double beta;
	//
	// When MOMENTS_DIST_CHARACT == UNIFORM, then the stochastic elements
	// of the network that are changed according to scenarios are each assumed
	// to follow a uniform(a, b) distribution where,
	// a = D - (alpha * D),
	// b = D + (beta * D),
	// D is the base value of the stochastic element taken from the base
	// deterministic network,
	// alpha in [0, 1),
	// beta in [0, \infty).
	// The distribution is symmetric around D when alpha = beta.
	//
	// When MOMENTS_DIST_CHARACT == TRIANGULAR, then the stochastic elements
	// of the network that are changed according to scenarios are each assumed
	// to follow a triangular(a, b, c) distribution where,
	// where,
	// a = D - (alpha * D),
	// b = D + (beta * D),
	// c = D,
	// D is the base value of the stochastic element taken from the base
	// deterministic network,
	// alpha in [0, 1),
	// beta in [0, \infty).
	// The distribution is symmetric around D when alpha = beta.
	//
	// name of file containing input instance (I)
	string inputInstFileName;

	// name of file containing output instance (O)
	string outputInstFileName;

	// name of file containing moments (I/O)
	string momentsFileName;

	// name of file containing correlations (I/O)
	string correlsFileName;

	// array identifying the stochastic elements
	VectStoch stochTypes;

	// array identifying the non-stochastic elements
	VectStoch nonStochTypes;

	// matrix of target correlation coefficients
	MatDbl correlCoeffsMatrix;
	//
	// supplied to Hoyland-Kaut-Wallace algorithm:
	//
	// number of scenarios
	int numbScenarios;

	// characteristics of moments (sum of bits)
	int distCharactMoments;

	// max error allowed when matching moments (scaled to var=1)
	double maxErrorMoment;

	// max error allowed when matching correlations (scaled to var=1)
	double maxErrorCorrel;

	// amount of information displayed by the program
	int displayLevel;

	// max number of attempts to generate scenarios
	int maxTrial;

	// max number of iterations in HKW algorithm
	int maxIter;

	// random seed (pcg_random)
	int randomSeed;

	// random stream (pcg_random)
	int randomStream;

	// name of file where resulting matrix of scenarios are written in HKW format (O)
	string scenariosFileName;

	// name of input file containing probabilities (optional) (I)
	string probsFileName;

	// name of file where a matrix of scenarios saved in HKW format
	// in a previous run (using option -o) are read and used as
	// starting values (optional) (I)
	string startScenariosFileName;

  // for validation purposes
  
  bool paramX;
  bool paramT;

	Configuration(int argc, char **argv);

	void printHelpAndExit();

	void printUsageAndExit(char ExecName[], bool anonymous);

	void validate();
};

#endif
