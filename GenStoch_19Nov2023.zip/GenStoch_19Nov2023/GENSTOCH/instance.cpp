// Copyright (c) 2023 Eric Larsen
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the “Software”), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
// ****************************************************************************
// ****************************************************************************
//
//
#include "instance.h"

// Assigns sizes to subarrays comprising master array of stochastic elements.
void Instance::assignSizes()
{
	stochElems[DEMAND].size = numbCommods;
	stochElems[CAP_ARC].size = numbArcs;
	stochElems[CAP_COMMOD].size = numbArcs * numbCommods;
	stochElems[FIXED_COST].size = numbArcs;
	stochElems[VAR_COST].size = numbArcs * numbCommods;
}

// Generates scenarios with Hoyland-Kaut-Wallace algorithm.
int Instance::getScenarios()
{

	printf(
			"\nBeginning generation of scenarios with Hoyland-Kaut-Wallace algorithm.\n");

	HoylandKautWallace hkw(numb_moments, stochElems[ALL_TYPES].size, params,
			stochElems);

	printf("\nEnd of Hoyland-Kaut-Wallace algorithm.\n");

	ofstream os(params->outputInstFileName);

	scenarios = hkw.generScenarios();

	return scenarios.ncol;
}

// Copies scenario to element array for the purpose of verifying feasibility with solver.
// (Vectors cannot be copied directly since the resulting matrix would be ill-structured.)
void Instance::copyScenario(int idx)
{
	for (int i = 0; i < scenarios.nrow; i++)   // index 1
		stochElems[ALL_TYPES].ptr[i] = scenarios.val[i][idx];
}

// Allocates arrays.
void Instance::allocate()
{
	int numbStochElem = 0;
	VectInt begin(MAX_TYPE, -1);

	stochElems.resize(ALL_TYPES + 1);

	for (int i = 0; i < MAX_TYPE; i++)
		stochElems[i].type = static_cast<STOCH_ELEMS_TYPE>(i);

	stochElems[ALL_TYPES].type = ALL_TYPES;
	assignSizes();

	for (uint i = 0; i < params->stochTypes.size(); i++)
	{
		STOCH_ELEMS_TYPE elem = params->stochTypes[i];
		begin[elem] = numbStochElem;
		numbStochElem += getSize(elem);
	}

	for (uint i = 0; i < params->nonStochTypes.size(); i++)
	{
		STOCH_ELEMS_TYPE elem = params->nonStochTypes[i];
		begin[elem] = 0;
	}

	stochElems[ALL_TYPES].ptr = (double*) malloc(
			numbStochElem * sizeof(double));
	stochElems[ALL_TYPES].size = numbStochElem;

	for (uint i = 0; i < params->nonStochTypes.size(); i++)
	{
		STOCH_ELEMS_TYPE elem = params->nonStochTypes[i];
		stochElems[elem].ptr = (double*) malloc(
				stochElems[elem].size * sizeof(double));
	}

	for (uint i = 0; i < params->stochTypes.size(); i++)
	{
		STOCH_ELEMS_TYPE elem = params->stochTypes[i];
		stochElems[elem].ptr = &stochElems[ALL_TYPES][begin[elem]];
	}

	Arc::setPtrCapac(stochElems[CAP_ARC].ptr);
	Arc::setPtrCost(stochElems[FIXED_COST].ptr);
	Commodity::setPtr(stochElems[DEMAND].ptr);
	CommodArc::setPtrCapac(stochElems[CAP_COMMOD].ptr);
	CommodArc::setPtrCost(stochElems[VAR_COST].ptr);
	arcs.resize(numbArcs);
	commods.resize(numbCommods);
	nodes.resize(numbNodes);
}

// Reads instance in Dow format.
void InstanceDow::read(istream &is)
{
	string line, dummy;
	double capac, volume, varCost, fixedCost;
	int countArc = 0, countDemand = 0, countComm = 0;

	getline(is, line);

	is >> numbNodes >> numbArcs >> numbCommods;

	allocate();

	for (int a = 0; a < numbArcs; a++)
	{
		Arc arc(numbCommods);
		int idxArc;

		is >> arc.orig >> arc.dest >> varCost   //arc.comms[0].cost
				>> capac >> fixedCost  //arc.cost
				>> dummy >> idxArc;

		arc.orig--;
		arc.dest--;
		stochElems[CAP_ARC][countArc] = capac;
		stochElems[FIXED_COST][countArc] = fixedCost;
		nodes[arc.orig].arcOut.push_back(countArc);
		nodes[arc.dest].arcIn.push_back(countArc);
		countArc++;
		idxArc--;

		for (int k = 0; k < numbCommods; k++)
		{
			stochElems[CAP_COMMOD][countComm] = capac;
			stochElems[VAR_COST][countComm] = varCost;
			countComm++;
		}

		arcs[idxArc] = arc;
	}

	for (int k = 0; k < numbCommods; k++)
	{
		is >> commods[k].orig >> commods[k].dest >> volume;

		commods[k].orig--;
		commods[k].dest--;
		stochElems[DEMAND][countDemand++] = volume;

		for (int a = 0; a < numbArcs; a++)
			*(arcs[a].comms[k].capac) = min(*(arcs[a].comms[k].capac), volume);
	}
}

// Writes instance in Dow format.
void InstanceDow::write(ostream &os) const
{
        static int scen = 0;
	os << " SCENARIO        " << scen++ << endl;
	os << " MULTIGEN.DAT:" << endl;
	os << setw(8) << right << numbNodes << setw(8) << right << numbArcs
			<< setw(8) << right << numbCommods << endl;

	for (int n = 0; n < numbNodes; n++)
		for (int a = 0; a < numbArcs; a++)
		{
			if (arcs[a].orig == n)
			{
				os << setw(8) << right << arcs[a].orig + 1 << setw(8) << right
						<< arcs[a].dest + 1 << setw(8) << right
						<< (int) *(arcs[a].comms[0].cost) << setw(8) << right
						<< (int) *(arcs[a].capac) << setw(8) << right
						<< (int) *(arcs[a].cost) << setw(8) << right << 1
						<< setw(8) << right << a + 1 << endl;
			}
		}

	for (int k = 0; k < numbCommods; k++)
	{
		os << setw(8) << right << commods[k].orig + 1 << setw(8) << right
				<< commods[k].dest + 1 << setw(8) << right
				<< (int) *(commods[k].volume) << endl;
	}
}

// Reads instance in Std format.
void InstanceStd::read(istream &is)
{
	string line, dummy;
	int numbComm, idxComm, idxNode, capac, volume, varCost, fixedCost;
	int countArc = 0, countDemand = 0, countComm = 0;

	is >> numbNodes >> numbArcs >> numbCommods;

	allocate();

	for (int a = 0; a < numbArcs; a++)
	{
		Arc arc(numbCommods);

		is >> arc.orig >> arc.dest >> fixedCost    // arc.cost
				>> capac >> numbComm;

		arc.orig--;
		arc.dest--;
		stochElems[CAP_ARC][countArc] = capac;
		stochElems[FIXED_COST][countArc] = fixedCost;
		nodes[arc.orig].arcOut.push_back(countArc);
		nodes[arc.dest].arcIn.push_back(countArc);
		countArc++;

		for (int k = 0; k < numbComm; k++)
		{
			is >> idxComm;
			idxComm--;
			is >> varCost   //arc.comms[idxComm].cost
					>> capac;

			stochElems[CAP_COMMOD][countComm] = capac;
			stochElems[VAR_COST][countComm] = varCost;
			countComm++;
		}

		arcs[a] = arc;
	}

	for (int k = 0; k < numbCommods * 2; k++)
	{
		is >> idxComm >> idxNode >> volume;

		idxComm--;
		idxNode--;

		if (volume < 0)
			commods[idxComm].dest = idxNode;
		else
		{
			commods[idxComm].orig = idxNode;
			stochElems[DEMAND][countDemand++] = volume;
		}
	}
}

// Writes instance in Std format.
void InstanceStd::write(ostream &os) const
{
        static int scen = 0;
	os << " SCENARIO        " << scen++ << endl;
	os << setw(8) << right << numbNodes << setw(8) << right << numbArcs
			<< setw(8) << right << numbCommods << endl;

	for (int n = 0; n < numbNodes; n++)
	{
		for (int a = 0; a < numbArcs; a++)
		{
			if (arcs[a].orig == n)
			{
				int count = 0;

				for (int k = 0; k < numbCommods; k++)
					if (*(arcs[a].comms[k].capac) != 0)
						count++;

				os << setw(8) << right << arcs[a].orig + 1 << setw(8) << right
						<< arcs[a].dest + 1 << setw(8) << right
						<< (int) *(arcs[a].cost) << setw(8) << right
						<< (int) *(arcs[a].capac) << setw(8) << right << count
						<< endl;

				for (int k = 0; k < numbCommods; k++)
					if (arcs[a].comms[k].capac != 0)
						os << setw(8) << right << k + 1 << setw(8) << right
								<< (int) *(arcs[a].comms[k].cost) << setw(8)
								<< right << (int) *(arcs[a].comms[k].capac)
								<< endl;
			}
		}
	}

	for (int k = 0; k < numbCommods; k++)
	{
		os << setw(8) << right << k + 1 << setw(8) << right
				<< commods[k].orig + 1 << setw(8) << right
				<< (int) *(commods[k].volume) << endl;
		os << setw(8) << right << k + 1 << setw(8) << right
				<< commods[k].dest + 1 << setw(8) << right
				<< (int) -*(commods[k].volume) << endl;
	}
}
