// Copyright (c) 2023 Eric Larsen
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the “Software”), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
// ****************************************************************************
// ****************************************************************************
//
//
#include "configuration.h"

// Constructor
//
Configuration::Configuration(int argc, char **argv) :
		instanceFormat(DOW), momentsCharacts(UNIFORM), generMoments(false), alpha(
				0.25), beta(0.25), randomStream(1), inputInstFileName(
				"test.dow"), outputInstFileName("output.txt"), momentsFileName(
				"tg_moms.txt"), correlsFileName("tg_corrs.txt"), numbScenarios(
				100), maxErrorMoment(1e-3), maxErrorCorrel(1e-3), displayLevel(
				2), maxTrial(10), maxIter(20), randomSeed(0), scenariosFileName(
				"out_scen.txt"), probsFileName(""), startScenariosFileName(""), paramX(
				false), paramT(false)

{
	// distCharactMoments(7), 7=1+2+4, is supplied to Hoyland-Kaut-Wallace algorithm,
	// where:
	// 1 -> use population estimators (as in spreadsheets),
	// 2 -> 2nd moment is Var instead of StDev,
	// 4 -> 4th moment is Kurtosis - 3,
	// Note: by default, 3rd and 4th moments are scaled by StDev.
	// To ensure expected working of program, it SHOULD be supplied with value 7.
	distCharactMoments(7);

	int elemStoch = DEMAND;

	correlCoeffsMatrix.resize(MAX_TYPE, VectDbl(MAX_TYPE, 0.0));

	if (argc == 1)
		printUsageAndExit(argv[0], false);

	if (argc == 2 && (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "-H") == 0))
		printHelpAndExit();

	for (int i = 1; i < argc; i += 2)
	{
		if ((argv[i][0] != '-') || (argc <= i + 1))
			printUsageAndExit(argv[0], false);

		switch (argv[i][1])
		{
		case 'F':
			if (argv[i + 1][0] == 'D')
			{
				instanceFormat = DOW;
				break;
			}
			if (argv[i + 1][0] == 'S')
			{
				instanceFormat = STD;
				break;
			}
			printUsageAndExit(argv[0], false);
			break;
		case 'T':
			if (argv[i + 1][0] == 'U')
			{
				momentsCharacts = UNIFORM;
				paramT = true;
				break;
			}
			if (argv[i + 1][0] == 'T')
			{
				momentsCharacts = TRIANGULAR;
				paramT = true;
				break;
			}
			printUsageAndExit(argv[0], false);
			break;
		case 'S':
			elemStoch = atoi(argv[i + 1]);

			if (elemStoch & flagStochDemand)
				stochTypes.push_back(DEMAND);
			else
				nonStochTypes.push_back(DEMAND);
			if (elemStoch & flagStochArcCapac)
				stochTypes.push_back(CAP_ARC);
			else
				nonStochTypes.push_back(CAP_ARC);
			if (elemStoch & flagStochCommodArcCapac)
				stochTypes.push_back(CAP_COMMOD);
			else
				nonStochTypes.push_back(CAP_COMMOD);
			if (elemStoch & flagStochFixedCost)
				stochTypes.push_back(FIXED_COST);
			else
				nonStochTypes.push_back(FIXED_COST);
			if (elemStoch & flagStochVarCost)
				stochTypes.push_back(VAR_COST);
			else
				nonStochTypes.push_back(VAR_COST);
			break;
		case 'X':
			STOCH_ELEMS_TYPE elem[2];

			if (strlen(argv[i]) == 4)
			{
				for (int j = 0; j < 2; j++)
					switch (argv[i][j + 2])
					{
					case 'D':
						elem[j] = DEMAND;
						break;
					case 'A':
						elem[j] = CAP_ARC;
						break;
					case 'C':
						elem[j] = CAP_COMMOD;
						break;
					case 'F':
						elem[j] = FIXED_COST;
						break;
					case 'V':
						elem[j] = VAR_COST;
						break;
					default:
						printUsageAndExit(argv[0], false);
						break;
					}

				paramX = true;
				correlCoeffsMatrix[elem[0]][elem[1]] = atof(argv[i + 1]);
				correlCoeffsMatrix[elem[1]][elem[0]] = atof(argv[i + 1]);
				break;
			}
			else
			{
				printUsageAndExit(argv[0], false);
				break;
			}

		case 'G':
			generMoments = true;
			--i;
			break;
		case 'M':
			momentsFileName = argv[i + 1];
			break;
		case 'C':
			correlsFileName = argv[i + 1];
			break;
		case 'A':
			alpha = atof(argv[i + 1]);
			break;
		case 'B':
			beta = atof(argv[i + 1]);
			break;
		case 'I':
			inputInstFileName = argv[i + 1];
			break;
		case 'O':
			outputInstFileName = argv[i + 1];
			break;

			// arguments supplied to Hoyland-Kaut-Wallace algorithm
		case 'n':
			numbScenarios = atoi(argv[i + 1]);
			break;
		case 't':
			maxTrial = atoi(argv[i + 1]);
			break;
		case 'i':
			maxIter = atoi(argv[i + 1]);
			break;

		case 'm':
			maxErrorMoment = atof(argv[i + 1]);
			break;
		case 'c':
			maxErrorCorrel = atof(argv[i + 1]);
			break;
		case 'l':
			displayLevel = atoi(argv[i + 1]);
			break;
		case 'r':
			randomSeed = atoi(argv[i + 1]);
			break;
		case 'R':
			randomStream = atoi(argv[i + 1]);
			break;
		case 'o':
			scenariosFileName = argv[i + 1];
			break;
		case 'p':
			probsFileName = argv[i + 1];
			break;
		case 's':
			startScenariosFileName = argv[i + 1];
			break;
		case 'h':
			printHelpAndExit();
			break;
		default:
			printUsageAndExit(argv[0], false);
			break;
		}
	}

	validate();
}

// Validates parameter values.
void Configuration::validate()
{
	if (inputInstFileName == "")
	{
		cerr << "No instance file (DOW ou STD)";
		cerr << "Use option -I" << endl;

		exit(1);
	}

	if (stochTypes.size() == 0)
	{
		cerr << "No stochastic type specified" << endl;
		cerr << "Use option -S" << endl;
		exit(1);
	}

	if (alpha < 0.0 || alpha > 0.99)
	{
		cerr << "alpha must be in [0, 0.99]" << endl;
		exit(1);
	}

	if (beta < 0.0)
	{
		cerr << "beta must be non-negative" << endl;
		exit(1);
	}

	if (!generMoments)
	{
		if (paramX)
		{
			cerr << "option X should be used in conjunction with option G"
					<< endl;
			exit(1);
		}

		if (paramT)
		{
			cerr << "option T should be used in conjunction with option G"
					<< endl;
			exit(1);
		}
	}
}

void Configuration::printHelpAndExit()
{
	printf("\n");

	printf(
			"This application randomly generates scenarios by matching target moments and\n");

	printf(
			"correlations for specified subsets of parameters of a given instance of the\n");
	printf(
			"deterministic multi-commodity, fixed charge, capacitated network design\n");
	printf(" (MCFND) problem. Details of this process are governed by user specified\n");
	printf(
			"configuration settings. The program published by Kaut that implements\n");
	printf(
			"the algorithm of Hoyland, Kaut and Wallace (HKW) is used to compute the\n");
	printf("scenarios.\n");
	printf("\n");
	printf(
			"These two paragraphs are adapted from ../HOYLAND_KAUT_WALLACE/sg_HKW.c:\n");
	printf("\n");
	printf(
			"Scenario generation code is based on paper 'A Heuristic for Moment-matching\n");
	printf(
			"Scenario Generation' by K. Høyland, M. Kaut & S.W. Wallace; Computational\n");
	printf("Optimization and Applications, 24 (2-3), pp. 169–185, 2003;\n");
	printf(
			"doi:10.1023/A:1021853807313. Code by Michal Kaut (michal.kaut@iot.ntnu.no)\n");
	printf("& Diego Mathieu.\n");
	printf("\n");
	printf(
			"The HKW code generates scenarios for multivariate random variables by\n");
	printf(
			"matching specified target first four moments and correlations. The algorithm\n");
	printf(
			"is iterative and reports distance from target values. Convergence is not\n");
	printf(
			"guaranteed and the algorithm can run in several trials if needed, starting\n");
	printf("each one from new random initializations.\n");
	printf("\n");
	printf("1 Building the program\n");
	printf("\n");
	printf("Under Linux, follow these steps to build the program:\n");
	printf("\n");
	printf(
			"a- Install CPLEX (if not already done) and note the installation directory\n");
	printf("b- Open the archive file containing the program files.\n");
	printf("c- Go to the directory just created\n");
	printf(
			"d- Edit file 'makefile' to set the variable CPLEX_HOME to the one noted in\n");
	printf("	step a- and save modified makefile to disk\n");
	printf("e- In the terminal, run:  make\n");
	printf("   to compile the program\n");
	printf("f- An executable file named 'exe' will be created\n");
	printf("\n");
	printf("2 Running the program\n");
	printf("\n");
	printf(
			"The general command for running the program on Linux is as follows:\n");
	printf("\n");
	printf("./exe -S <stochasticElements> [main options] [HKW options]\n");
	printf("\n");
	printf(
			"If running ./exe without any options, the list of all options for the\n");
	printf(
			"managing code (identified with capital letters) and for the HKW program\n");
	printf("(identified with lower case letters) will be displayed.\n");
	printf("\n");
	printf(
			"Option '-S <number>' must be invoked to determine which subsets of parameters\n");
	printf(
			"are meant to vary between scenarios (we call them the stochastic\n");
	printf(
			"elements). This option (-S) expects a number (from 1 to 31) that is a\n");
	printf("sum of the following bits:\n");
	printf("1 -> demands\n");
	printf("2 -> total capacities of arcs\n");
	printf("4 -> commodity-specific capacities of arcs\n");
	printf("8 -> fixed costs\n");
	printf("16 -> variable costs\n");
	printf("\n");
	printf(
			"Other options have default values that are hard-coded in the file\n");
	printf("configuration.cpp.\n");
	printf("\n");
	printf("Hence, running this command line:\n");
	printf("\n");
	printf("./exe -S 11\n");
	printf("\n");
	printf(
			"indicates to the program that fixed costs (8), total capacities of arcs (2) and\n");
	printf("demands (1) must be randomized (8 + 2 + 1 = 11).\n");
	printf("\n");
	printf(
			"The value of any option specified on the command line will override that\n");
	printf(
			"specified in file configuration.cpp. If the value of an option is specified\n");
	printf("more than once on the command line, the last value is retained.\n");
	printf("\n");
	printf("DETAILED USAGE OF ALL OPTIONS IS SUPPLIED FURTHER BELOW.\n");
	printf("\n");
	printf("Here are some pointers and two examples:\n");
	printf("\n");
	printf(
			"The default input instance is set to test.dow and the default input format is\n");
	printf("set to DOW. If the input instance is changed with option\n");
	printf(
			"'-I <input instance>', it is critical that the input format is set\n");
	printf("accordingly with option '-F <format>'. For example:\n");
	printf("\n");
	printf("./exe -S 3 -I instB.std -F S\n");
	printf("\n");
	printf(
			"indicates that demands and total capacities of arcs will be randomized based\n");
	printf("on the instance instB.std which has the format 'S' (thus STD).\n");
	printf("\n");
	printf(
			"Target moments and correlations can be EITHER specified in files OR\n");
	printf(
			"generated by the program based on default settings and indications supplied\n");
	printf(
			"on the command line. If they are to be generated, use option '-G'.\n");
	printf(
			"A single target correlation coefficient within subset of parameters U or\n");
	printf(
			"between subsets of parameters U and V can be specified with '-X<UU> <value>'\n");
	printf(
			"and '-X<UV> <corr>' respectively, where corr is the target correlation\n");
	printf("coefficient and U and V can take these values:\n");
	printf("D -> demands\n");
	printf("A -> total capacities of arcs\n");
	printf("C -> commodity-specific capacities of arcs\n");
	printf("F -> fixed costs\n");
	printf("V -> variable costs\n");
	printf(
			"Target correlations that are unspecified are assumed by default to be zero.\n");
	printf(
			"Target moments are generated based (i) on a distributional assumption that\n");
	printf(
			"can be specified using option '-T <dist>' where dist stands for either U\n");
	printf(
			"(uniform) or D (triangular) and (ii) on two parameters, alpha and beta, that\n");
	printf(
			"can be specified using options '-A <alpha>' and '-B <beta>'. Any use of\n");
	printf(
			"options -X, -T, -A or -B without option -G will be rejected. Hence, the\n");
	printf(
			"following command line specifies target correlations among demands of 0.5,\n");
	printf(
			"between demands and total capacities of arcs of -0.3, and among total\n");
	printf(
			"capacities of arcs of 0.7. It specifies that the target first four moments\n");
	printf(
			"of all randomized parameters will be calculated based on uniform\n");
	printf("distributions using alpha = beta = 0.25.\n");
	printf("\n");
	printf(
			"ex.:  ./exe -S 3 -I instB.std -F S -G -XDD 0.5 -XDA -0.3 -XAA 0.7 -T U -A 0.25 -B 0.25\n");
	printf("\n");
	printf("3 Output file\n");
	printf("\n");
	printf(
			"The output file yielded by the program superposes complete deterministic\n");
	printf(
			"problem instances, one for each scenario realization. Each instance is\n");
	printf("preceded by a separator as follows:\n");
	printf("\n");
	printf("SCENARIO   <scenario number>\n");
	printf("\n");
	printf(
			"Immediately after the separator, the instance corresponding to the\n");
	printf(
			"identified scenario is fully described with the same format, DOW or STD, as\n");
	printf(
			"that used to supply the base deterministic problem instance. Stacking and\n");
	printf(
			"separating full descriptions of scenario realizations in this fashion makes\n");
	printf(
			"it easy to pinpoint and read the first and second stages information\n");
	printf("relevant to every individual scenario.\n");
	printf("\n");
	printf("4 Format of input files supplied to HKW algorithm\n");
	printf("(adapted from ../HOYLAND_KAUT_WALLACE/sg_HKW.c)\n");
	printf("\n");
	printf("4.1 Target moments and correlations\n");
	printf("\n");
	printf(
			"When option -G is absent from command line and unless overridden by parameter\n");
	printf("-M, target moments are read from file named 'tg_moms.txt'.\n");
	printf("\n");
	printf(
			"When option -G is absent from command line and unless overridden by parameter\n");
	printf(
			"-C, target correlations are read from file named 'tg_corrs.txt'.\n");
	printf("\n");
	printf(
			"These text files include a matrix of numbers in the following format\n");
	printf("(hence the target moments file has 6 rows):\n");
	printf("number of rows\n");
	printf("number of columns\n");
	printf("data (by rows)\n");
	printf("(rest of the file is ignored)\n");
	printf("\n");
	printf(
			"IMPORTANT: Expected definitions of the 4 target moments are as follows:\n");
	printf("(i) population estimators are used (as in spreadsheets)\n");
	printf("(ii) 2nd moment is variance and NOT standard deviation\n");
	printf("(iii) 4th moment is kurtosis - 3\n");
	printf("(iv) 3rd and 4th moments are normalized with standard deviation\n");
	printf("\n");
	printf("4.2 Probabilities of scenarios\n");
	printf("\n");
	printf(
			"If the probabilities ARE NOT supplied in a file, then scenarios are assumed\n");
	printf(
			"to be equiprobable. If the probabilities ARE supplied in a file, the file has\n");
	printf("to be in a vector format:\n");
	printf("number of elements\n");
	printf("data\n");
	printf("(rest of the file is ignored)\n");
	printf("\n");
	printf("4.3 Saved scenarios\n");
	printf("\n");
	printf(
			"Scenarios saved in HKW format in a previous run (using option -o) can be\n");
	printf(
			"used as starting values in a next run (using option -s). These will only\n");
	printf(
			"be used in the first trial. If this does not converge and the maximum\n");
	printf(
			"number of trials specified by option -t is larger than 1, the next trials\n");
	printf("start from a random starting point.\n");
	printf(
			"IMPORTANT: Scenarios in HKW format written in file identified with option -o\n");
	printf(
			"are distinct from desired output of the program written in file identified\n");
	printf("with option -O and described in Section 3 above.\n");
	printUsageAndExit(0, true);
	exit(1);

}

void Configuration::printUsageAndExit(char ExecName[], bool anonymous)
{

	if (!anonymous)
	{
		printf(
				"\nUsage: %s [main options (section 1 below)] [HKW options (section 2 below)]\n",
				ExecName);
	}
	else
	{
		printf("Usage of options\n");
	}
	printf("\n");
	printf("(Some parts adapted from ../HOYLAND_KAUT_WALLACE/sg_HKW.c.)\n");
	printf("\n");
	printf("1- Main generator options\n");
	printf("\n");
	printf("-h <> (no value supplied); display help message\n");
	printf("\n");
	printf("-F <char>; format of base deterministic input instance\n");
	printf("(D: DOW, S: STD); default: D\n");
	printf("\n");
	printf(
			"\nDOW and STD formats are specific to MCFND problems and described in files\n");
	printf(
			"DOW-format-desc.txt and STD-format-desc.txt; DOW presupposes that for each\n");
	printf(
			"arc, capacities and variable costs are identical for all commodities;\n");

	printf("\n");

	printf(
			"-I <string>; name of file where deterministic MCFND base instance is to be\n");
	printf("read; default: test.dow\n");
	printf("\n");
	printf(
			"-O <string>; name of file where instances resulting from scenario\n");
	printf("generations are to be written; default: output.txt\n");
	printf("\n");
	printf(
			"-S <int>; identifies which subsets of parameters are meant to vary between\n");
	printf(
			"scenarios; expects a number (from 1 to 31) that is a sum of the following\n");
	printf("bits:\n");
	printf("1 -> demands\n");
	printf("2 -> capacity on arcs\n");
	printf("4 -> capacity on arcs by commodity\n");
	printf("8 -> fixed costs\n");
	printf("16 -> variable costs\n");
	printf("\n");
	printf(
			"-G <> (no value supplied); if present, target moments and target\n");
	printf(
			"correlations are generated based on options -T and -X and WRITTEN according\n");
	printf(
			"to options -M and -C. If absent, they are READ according to options -M and\n");
	printf("-C.\n");
	printf("\n");
	printf(
			"-C <string>; name of file where target correlations are read if -G is absent\n");
	printf(
			"and where generated target correlations are written if -G is present;\n");
	printf("default: tg_corrs.txt\n");
	printf("\n");
	printf(
			"-X<char><char> <double>; identifies target correlations within sets of\n");
	printf(
			"parameters or between sets of parameters (state once for each pair of sets):\n");
	printf("D -> demands\n");
	printf("A -> total capacities of arcs\n");
	printf("C -> commodity-specific capacities of arcs\n");
	printf("F -> fixed costs\n");
	printf("V -> variable costs\n");
	printf(
			"example: -XDD 0.9 -XFD 0.1 -XFF 0.01 specifies target correlations within\n");
	printf(
			"demand parameters of 0.9, between fixed cost parameters and demand parameters\n");
	printf("of 0.1 and within fixed cost parameters of 0.01;\n");
	printf("any use of -X without -G will be rejected;\n");
	printf("N.B.: -XFD and -XDF are equivalent;\n");
	printf("default: zero correlation\n");
	printf("\n");
	printf(
			"-M <string>; name of file where target moments are read if -G is absent or\n");
	printf("where generated target moments are written if -G is present;\n");
	printf("default: tg_moms.txt\n");
	printf("\n");
	printf(
			"-T <char>; distributional characteristics of generated target moments\n");
	printf(
			"( U : UNIFORM , T : TRIANGULAR ); any use of -T without -G will be rejected;\n");
	printf("default: U\n");
	printf("\n");
	printf(
			"-A <double>; parameter alpha used in generating target moments (see below);\n");
	printf("any use of -A without -G will be rejected;\n");
	printf("default: 0.25\n");
	printf("\n");
	printf(
			"-B <double>; parameter beta used in generating target moments (see below);\n");
	printf("any use of -B without -G will be rejected;\n");
	printf("default: 0.25\n");
	printf("\n");
	printf(
			"When MOMENTS_DIST_CHARACT == UNIFORM, then the stochastic elements\n");
	printf(
			"of the network that are changed according to scenarios are each assumed\n");
	printf("to follow a uniform(a, b) distribution where,\n");
	printf("a = D - (alpha * D),\n");
	printf("b = D + (beta * D),\n");
	printf(
			"D is the base value of the stochastic element taken from the base\n");
	printf("deterministic network,\n");
	printf("alpha in [0, 1),\n");
	printf("beta >= 0.\n");
	printf("The distribution is symmetric around D when alpha = beta.\n");
	printf("\n");
	printf(
			"When MOMENTS_DIST_CHARACT == TRIANGULAR, then the stochastic elements\n");
	printf(
			"of the network that are changed according to scenarios are each assumed\n");
	printf("to follow a triangular(a, b, c) distribution where,\n");
	printf("where,\n");
	printf("a = D - (alpha * D),\n");
	printf("b = D + (beta * D),\n");
	printf("c = D,\n");
	printf(
			"D is the base value of the stochastic element taken from the base\n");
	printf("deterministic network,\n");
	printf("alpha in [0, 1),\n");
	printf("beta >= 0.\n");
	printf("The distribution is symmetric around D when alpha = beta.\n");
	printf("\n");
	printf("2- Options supplied to Hoyland-Kaut-Wallace (HKW) algorithm\n");
	printf("\n");
	printf(
			"Scenario generation code is based on paper 'A Heuristic for Moment-matching\n");
	printf(
			"Scenario Generation' by K. Høyland, M. Kaut & S.W. Wallace; Computational\n");
	printf("Optimization and Applications, 24 (2-3), pp. 169–185, 2003; \n");
	printf(
			"doi:10.1023/A:1021853807313. Code by Michal Kaut (michal.kaut@iot.ntnu.no)\n");
	printf("& Diego Mathieu. Additional details about HKW options in\n");
	printf("../HOYLAND_KAUT_WALLACE/sg_HKW.c.\n");
	printf("\n");
	printf("-n <int>; number of scenarios to generate; default: 100\n");
	printf("\n");
	printf(
			"-t <int>; maximum number of trials (attempts to generate) using alternative\n");
	printf("random starting values; default: 10\n");
	printf("\n");
	printf("-i <int>; maximum number of iterations in a trial; default: 20\n");
	printf("\n");
	printf(
			"-m <double>; maximal error in matching moments (scaled to var=1);\n");
	printf("default: 0.001\n");
	printf("\n");
	printf(
			"-c <double>; maximal error in matching correlations (scaled to var=1);\n");
	printf("default: 0.001\n");
	printf("\n");
	printf(
			"-l <int>; level of on-screen reporting by HKW algorithm (between 0 and 11);\n");
	printf("default: 2\n");
	printf("\n");
	printf(
			"-o <string>; name of file where resulting matrix of scenarios in HKW format\n");
	printf("is written; default: out_scen.txt\n");
	printf("\n");
	printf(
			"-s <string>; if present, name of file where a starting matrix of scenarios\n");
	printf(
			"saved in HKW format in a previous run (using option -o) is read and used for\n");
	printf("starting values\n");
	printf("\n");
	printf(
			"-p <string>; if present, read probabilities from this file; otherwise,\n");
	printf("scenarios are assumed equiprobable\n");
	printf("\n");
	printf("-r <int>; random seed; default: 0\n");
	printf("\n");
	printf("-R <int>; random stream; default: 1\n");
	printf("\n");
	printf("Example of command line:\n");
	printf(
			"./exe -I test.dow -F D -G -i 500 -S 3 -XDD 0.5 -XAA 0.5 -XAD -0.2 -n 10000 -R 1212121 -r 1212 -A 0.5 -B 0.5\n");

	exit(1);
}

