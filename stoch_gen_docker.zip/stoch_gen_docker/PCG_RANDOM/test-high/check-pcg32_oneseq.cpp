#define RNG pcg32_oneseq
#define TWO_ARG_INIT 0

#include "pcg-test.cpp"

