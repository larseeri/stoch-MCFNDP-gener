#define RNG pcg32_k64_fast
#define TWO_ARG_INIT 0

#include "pcg-test.cpp"

